COPYRIGHT � BLUEWEBTEMPLATES.COM & DREAMTEMPLATE.COM
ALL RIGHTS RESERVED

Thank you for downloading our templates! Each template
takes hours to design and code. Please support us to
continue development and maintenance by leaving the 
credit links on each template!

This work is under Creative Commons Attribution-Share Alike 3.0 License.
http://creativecommons.org/licenses/by-sa/3.0/

This means you may use it and make any changes you like. 
However, credit links must remain on footer for legal use.
 
For more information visit:
http://www.bluewebtemplates.com/
http://www.dreamtemplate.com/

##########################################

Installation Instructions:

1. Simple edit index.html and add your own content
2. Upload these pages to your web host

##########################################